package com.akiisx.luckyblock.config;

import com.akiisx.luckyblock.LuckyBlock;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class MessagesManager {
    private final LuckyBlock plugin;
    private final File messagesFile;
    private FileConfiguration messages;

    public MessagesManager(LuckyBlock plugin) {
        this.plugin = plugin;
        this.messagesFile = new File(plugin.getDataFolder(), "messages.yml");
        reload();
    }

    public void reload() {
        if (!messagesFile.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        this.messages = YamlConfiguration.loadConfiguration(messagesFile);

        InputStream defaultStream = plugin.getResource("messages.yml");
        if (defaultStream != null) {
            YamlConfiguration defaults = YamlConfiguration.loadConfiguration(
                new InputStreamReader(defaultStream, StandardCharsets.UTF_8)
            );
            this.messages.setDefaults(defaults);
        }
    }

    public String getMessage(String path) {
        String raw = messages.getString(path, "&cMissing message: " + path);
        return ChatColor.translateAlternateColorCodes('&', raw);
    }

    public String getMessageWithPrefix(String path, String... placeholders) {
        String prefix = getMessage("prefix");
        String msg = getMessage(path);
        for (int i = 0; i + 1 < placeholders.length; i += 2) {
            msg = msg.replace(placeholders[i], placeholders[i + 1]);
        }
        return prefix + msg;
    }

    public String getLogMessage(String path, String... placeholders) {
        String raw = messages.getString("logs." + path, path);
        raw = ChatColor.translateAlternateColorCodes('&', raw);
        for (int i = 0; i + 1 < placeholders.length; i += 2) {
            raw = raw.replace(placeholders[i], placeholders[i + 1]);
        }
        return ChatColor.stripColor(raw);
    }
}
package com.akiisx.luckyblock.data;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SoundConfig {
    private boolean enabled;
    private String sound;
    private float volume;
    private float pitch;
}
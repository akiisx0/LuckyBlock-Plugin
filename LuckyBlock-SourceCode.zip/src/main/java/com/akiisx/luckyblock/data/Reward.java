package com.akiisx.luckyblock.data;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class Reward {
    private String id;
    private double chance;
    private List<String> commands;
    private String broadcast;
    private String rewardName;
}
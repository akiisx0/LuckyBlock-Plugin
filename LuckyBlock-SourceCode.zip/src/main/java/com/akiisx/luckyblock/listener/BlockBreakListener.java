package com.akiisx.luckyblock.listener;

import com.akiisx.luckyblock.LuckyBlock;
import com.akiisx.luckyblock.data.LuckyBlockType;
import com.akiisx.luckyblock.data.ParticleConfig;
import com.akiisx.luckyblock.data.Reward;
import com.akiisx.luckyblock.data.SoundConfig;
import com.cryptomorin.xseries.XMaterial;
import com.cryptomorin.xseries.XSound;
import com.cryptomorin.xseries.particles.XParticle;
import com.cryptomorin.xseries.profiles.objects.Profileable;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.block.Skull;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BlockBreakListener implements Listener {
    private final LuckyBlock plugin;
    private final Random random;
    
    public BlockBreakListener(LuckyBlock plugin) {
        this.plugin = plugin;
        this.random = new Random();
    }
    
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        
        if (plugin.getConfigManager().getDisabledWorlds().contains(block.getWorld().getName())) {
            return;
        }
        
        if (isLuckyBlock(block)) {
            handleLuckyBlockBreak(event, player, block);
            return;
        }
        
        if (player.getGameMode() == GameMode.CREATIVE) {
            return;
        }
        
        XMaterial material = XMaterial.matchXMaterial(block.getType());
        double chance = plugin.getConfigManager().getMiningChance(material);
        
        if (chance > 0 && random.nextDouble() * 100 < chance) {
            giveLuckyBlock(player);
        }
    }
    
    private boolean isLuckyBlock(Block block) {
        XMaterial material = XMaterial.matchXMaterial(block.getType());
        if (material != XMaterial.PLAYER_HEAD && material != XMaterial.PLAYER_WALL_HEAD) {
            return false;
        }
        
        if (!(block.getState() instanceof Skull)) {
            return false;
        }
        
        Skull skull = (Skull) block.getState();
        if (skull.getPlayerProfile() == null) {
            return false;
        }
        
        String configTexture = plugin.getConfigManager().getSkullOwner();
        if (configTexture == null || configTexture.isEmpty()) {
            return false;
        }
        
        String skullTexture = getSkullTexture(skull);
        if (skullTexture == null) {
            return false;
        }
        
        if (configTexture.startsWith("http")) {
            return skullTexture.contains(configTexture.substring(configTexture.lastIndexOf("/") + 1));
        } else {
            return skull.getOwningPlayer() != null && 
                   configTexture.equalsIgnoreCase(skull.getOwningPlayer().getName());
        }
    }
    
    private String getSkullTexture(Skull skull) {
        try {
            if (skull.getPlayerProfile() != null && skull.getPlayerProfile().getTextures() != null) {
                if (skull.getPlayerProfile().getTextures().getSkin() != null) {
                    return skull.getPlayerProfile().getTextures().getSkin().toString();
                }
            }
        } catch (Exception e) {
        }
        return null;
    }
    
    private void handleLuckyBlockBreak(BlockBreakEvent event, Player player, Block block) {
        if (plugin.getConfigManager().isPermissionEnabled()) {
            if (!player.hasPermission(plugin.getConfigManager().getPermission())) {
                if (plugin.getConfigManager().isPreventBreak()) {
                    event.setCancelled(true);
                }
                if (plugin.getConfigManager().isPermissionMessageEnabled()) {
                    player.sendMessage(plugin.getMessagesManager().getMessageWithPrefix("errors.cannot-open"));
                }
                return;
            }
        }
        
        event.setCancelled(true);
        
        Location location = block.getLocation().clone();
        
        block.setType(XMaterial.AIR.parseMaterial());
        
        List<LuckyBlockType> types = new ArrayList<>(plugin.getLuckyBlockManager().getAllLuckyBlocks().values());
        if (types.isEmpty()) {
            return;
        }
        
        LuckyBlockType type = types.get(0);
        
        plugin.getAnimationManager().playAnimation(player, location, () -> {
            executeReward(player, type, location);
        });
    }
    
    private void executeReward(Player player, LuckyBlockType type, Location location) {
        Reward selectedReward = selectReward(type.getRewards());
        
        if (selectedReward == null) {
            return;
        }
        
        if (selectedReward.getCommands() != null) {
            for (String command : selectedReward.getCommands()) {
                String processedCommand = command.replace("%player%", player.getName());
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), processedCommand);
            }
        }
        
        if (selectedReward.getBroadcast() != null && !selectedReward.getBroadcast().isEmpty()) {
            String broadcast = selectedReward.getBroadcast().replace("%player%", player.getName());
            Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', broadcast));
        }
        
        if (type.getParticles() != null && type.getParticles().isEnabled()) {
            playParticles(location, type.getParticles());
        }
        
        if (type.getSounds() != null && type.getSounds().isEnabled()) {
            playSound(player, location, type.getSounds());
        }
        
        plugin.getDataLogger().logOpening(
            player.getName(),
            type.getId(),
            selectedReward.getId(),
            selectedReward.getRewardName()
        );
    }
    
    private Reward selectReward(List<Reward> rewards) {
        if (rewards == null || rewards.isEmpty()) {
            return null;
        }
        
        double totalChance = rewards.stream().mapToDouble(Reward::getChance).sum();
        double randomValue = random.nextDouble() * totalChance;
        
        double cumulative = 0.0;
        for (Reward reward : rewards) {
            cumulative += reward.getChance();
            if (randomValue <= cumulative) {
                return reward;
            }
        }
        
        return rewards.get(rewards.size() - 1);
    }
    
    private void playParticles(Location location, ParticleConfig config) {
        if (location.getWorld() == null) return;
        
        XParticle.of(config.getEffect()).ifPresent(particle -> {
            location.getWorld().spawnParticle(
                particle.get(),
                location.clone().add(0.5, 0.5, 0.5),
                config.getAmount(),
                config.getOffsetX(),
                config.getOffsetY(),
                config.getOffsetZ(),
                0.0
            );
        });
    }
    
    private void playSound(Player player, Location location, SoundConfig config) {
        XSound.matchXSound(config.getSound()).ifPresent(sound -> {
            player.playSound(location, sound.parseSound(), config.getVolume(), config.getPitch());
        });
    }
    
    private void giveLuckyBlock(Player player) {
        List<LuckyBlockType> types = new ArrayList<>(plugin.getLuckyBlockManager().getAllLuckyBlocks().values());
        if (types.isEmpty()) return;
        
        LuckyBlockType randomType = types.get(random.nextInt(types.size()));
        ItemStack luckyBlock = plugin.getLuckyBlockManager().getLuckyBlockItem(randomType.getId(), 1);
        
        if (luckyBlock != null) {
            player.getInventory().addItem(luckyBlock);
            player.sendMessage(plugin.getMessagesManager().getMessageWithPrefix("mining.found"));
            
            plugin.getDataLogger().logMining(
                player.getName(),
                XMaterial.matchXMaterial(player.getInventory().getItemInMainHand().getType()).name(),
                randomType.getId()
            );
        }
    }
    
}
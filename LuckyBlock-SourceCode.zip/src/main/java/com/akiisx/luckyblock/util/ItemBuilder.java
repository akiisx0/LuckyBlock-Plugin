package com.akiisx.luckyblock.util;

import com.cryptomorin.xseries.XMaterial;
import com.cryptomorin.xseries.profiles.builder.XSkull;
import com.cryptomorin.xseries.profiles.objects.Profileable;
import org.bukkit.ChatColor;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ItemBuilder {
    private ItemStack item;
    private ItemMeta meta;
    
    public ItemBuilder(XMaterial material) {
        this.item = material.parseItem();
        if (this.item != null) {
            this.meta = this.item.getItemMeta();
        }
    }
    
    public ItemBuilder(ItemStack item) {
        this.item = item;
        if (this.item != null) {
            this.meta = this.item.getItemMeta();
        }
    }
    
    public ItemBuilder setDisplayName(String name) {
        if (meta != null) {
            meta.setDisplayName(colorize(name));
        }
        return this;
    }
    
    public ItemBuilder setLore(List<String> lore) {
        if (meta != null && lore != null) {
            List<String> coloredLore = lore.stream()
                .map(this::colorize)
                .collect(Collectors.toList());
            meta.setLore(coloredLore);
        }
        return this;
    }
    
    public ItemBuilder setSkullTexture(String texture) {
        if (texture != null && !texture.isEmpty()) {
            String displayName = meta != null && meta.hasDisplayName() ? meta.getDisplayName() : null;
            List<String> lore = meta != null && meta.hasLore() ? meta.getLore() : null;
            
            if (texture.startsWith("http")) {
                this.item = XSkull.createItem().profile(Profileable.detect(texture)).apply();
            } else {
                this.item = XSkull.createItem().profile(Profileable.username(texture)).apply();
            }
            this.meta = this.item.getItemMeta();
            
            if (displayName != null) {
                meta.setDisplayName(displayName);
            }
            if (lore != null) {
                meta.setLore(lore);
            }
        }
        return this;
    }
    
    public ItemBuilder addNBTTag(String key, String value) {
        if (meta != null) {
            try {
                NamespacedKey namespacedKey = new NamespacedKey("luckyblock", key);
                meta.getPersistentDataContainer().set(namespacedKey, PersistentDataType.STRING, value);
            } catch (Exception e) {
            }
        }
        return this;
    }
    
    public boolean hasNBTTag(String key) {
        if (meta == null) return false;
        try {
            NamespacedKey namespacedKey = new NamespacedKey("luckyblock", key);
            return meta.getPersistentDataContainer().has(namespacedKey, PersistentDataType.STRING);
        } catch (Exception e) {
            return false;
        }
    }
    
    public String getNBTTag(String key) {
        if (meta == null) return null;
        try {
            NamespacedKey namespacedKey = new NamespacedKey("luckyblock", key);
            return meta.getPersistentDataContainer().get(namespacedKey, PersistentDataType.STRING);
        } catch (Exception e) {
            return null;
        }
    }
    
    public ItemStack build() {
        if (item != null && meta != null) {
            item.setItemMeta(meta);
        }
        return item;
    }
    
    private String colorize(String text) {
        if (text == null) return "";
        return ChatColor.translateAlternateColorCodes('&', text);
    }
}